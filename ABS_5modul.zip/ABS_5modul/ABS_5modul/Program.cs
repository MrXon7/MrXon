﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABS_5modul
{
    class Program
    {
        static void Main(string[] args)
        {
            //14 1misol
            /*int n = Convert.ToInt32(Console.ReadLine());
            for(int i=0; i < n; i++)
            {
                for(int j=-n;j<0; j++)
                {
                    if ((19 * i * i + 28 * j * j) == 729)
                    {
                        Console.WriteLine(i + "" + j);
                    }
                }
            }*/
            /*for (int i = 0; i < 2005; i++)
            {
                for (int j = 0j < 2005; j++)
                {
                    if ((i + j) * (i - j) == 2005)
                    {
                        Console.WriteLine(i + "" + j);
                    }

                }
            }*/
            int n = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <n; j++)
                {
                    if ((float)((Math.Pow(i, 3) * Math.Pow(j, 3) + Math.Pow(i, 2)) / (i * Math.Pow(j, 3) + 1)) == (float)229 / 55)
                    {
                        Console.WriteLine(i + "," + j);
                    }
                    else
                    {
                        Console.WriteLine("xato");
                    }
                }
            }
            Console.ReadKey(); 
        }
    }
}
